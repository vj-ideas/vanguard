import numpy as np
import cv2
from cv2 import aruco
import math
import time
import socket
import pandas as pd
import csv

bot_aruco_id = 100

def find_most_frequent_event(column):
    event_counts = column[column != "unknown"].value_counts()
    if len(event_counts) > 0:
        return event_counts.idxmax()
    else:
        return "unknown"

def get_array_ids_list(df):
    newdict = {}
    for column in df.columns[0:]:
        most_frequent_event = find_most_frequent_event(df[column])
        newdict[column] = most_frequent_event

    priority_order = ["fire","destroyed_buildings", "fire", "human_aid_rehabilitation", "military_vehicles", "combat", "blank"]
    priority_list = sorted(newdict.values(), key=lambda x: priority_order.index(x))
    bot_list = [value for value in priority_list if value != "blank"]

    priority_dictionary = {}
    for event in bot_list:
        for key, value in newdict.items():
            if value == event:
                priority_dictionary[key] = value
                break

    event_to_array_id = {'A': 21, 'B': 29, 'C': 31, 'D': 34, 'E': 48}

    priority_dictionary_with_array_ids = {}
    for key, value in priority_dictionary.items():
        array_id = event_to_array_id[key]
        priority_dictionary_with_array_ids[key] = {'array_id': array_id, 'event': value}

    array_ids_list = [entry['array_id'] for entry in priority_dictionary_with_array_ids.values()]
   
    return array_ids_list, priority_dictionary

def get_all_arrays(priority_dictionary):

   # Define the arrays
    SA = [2]
    SB = [1, 2, 1]
    SC = [1, 1, 2, 1]
    SD = [1, 1, 2]
    SE = [1, 1, 1, 1]

    AB = [3, 2]
    AC = [3, 1, 2]
    AD = [3, 3, 2, 2]
    AE = [3, 3, 2 , 1, 1]
    AS = [5,7]

    BA = [5,1,3,3]
    BC = [5,2,2]
    BD = [5,1,2,2]
    BE = [5,1,2,1,1]
    BS = [5,1,3,6]

    CA = [2,2,1,3,3]
    CB = [5,3,3]
    CD = [5,1]
    CE = [5,1,2,1]
    CS = [2,2,1,3,6]

    DA = [2,2,3,3]
    DB = [2,3]
    DC = [1]
    DE = [3,3,2]
    DS = [2,2,3,6]

    EA = [1,1,2,1,3,3]
    EB = [1,2,3,3]
    EC = [2,3,3]
    ED = [2,1,3,3]
    ES = [1,1,2,1,3,6]


    array_mapping = {
        "A": SA, "B": SB, "C": SC, "D": SD, "E": SE,
        "AB": AB, "AC": AC, "AD": AD, "AE": AE, "AS" : AS,
        "BA": BA, "BC": BC, "BD": BD, "BE": BE, "BS": BS,
        "CA": CA, "CB": CB, "CD": CD, "CE": CE, "CS": CS,
        "DA": DA, "DB": DB, "DC": DC, "DE": DE, "DS": DS,
        "EA": EA, "EB": EB, "EC": EC, "ED": ED, "ES": ES,
    }

    new_priority_dict = {}
    keys = list(priority_dictionary.keys())
    for i in range(len(keys)):
        if i == 0:
            new_priority_dict[keys[i]] = priority_dictionary[keys[i]]
        else:
            new_priority_dict[keys[i-1] + keys[i]] = priority_dictionary[keys[i]]

    pre_final_array = list(priority_dictionary.keys())
    pre_final_array[-1] += "S"

    final_array = []
    final_array.insert(len(final_array), pre_final_array[-1])

    new_arr = list(new_priority_dict.keys())
    new_arr.extend(final_array)

    all_arrays = [array_mapping[key] for key in new_arr]
    return all_arrays


def mark_ArUco_image(image, ArUco_details_dict, ArUco_corners, desired_id, all_ids):
    for ids, details in ArUco_details_dict.items():
        center = details[0]
        cv2.circle(image, center, 5, (0, 0, 255), -1)

        if ids == bot_aruco_id:
            # Draw circle around ID 100
            radius = 200  # Set the radius of the circle
            cv2.circle(image, center, radius, (0, 255, 0), 2)

            # Draw line from center of ID 100 to the center of the desired ID
            if desired_id in ArUco_details_dict:
                desired_center = ArUco_details_dict[desired_id][0]
                cv2.line(image, center, tuple(desired_center), (255, 0, 0), 5)
                # Calculate the angle of the line (in degrees) using atan2
                angle_rad = math.atan2(desired_center[1] - center[1], desired_center[0] - center[0])
                angle_deg = math.degrees(angle_rad)
                # Display the angle
                cv2.putText(image, f"Angle: {angle_deg:.2f}", (center[0], center[1] - 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
           
        corner = ArUco_corners[int(ids)]
        cv2.circle(image, (int(corner[0][0]), int(corner[0][1])), 3, (50, 50, 50), -1)
        cv2.circle(image, (int(corner[1][0]), int(corner[1][1])), 3, (0, 255, 0), -1)
        cv2.circle(image, (int(corner[2][0]), int(corner[2][1])), 3, (128, 0, 255), -1)
        cv2.circle(image, (int(corner[3][0]), int(corner[3][1])), 3, (25, 255, 255), -1)

        tl_tr_center_x = int((corner[0][0] + corner[1][0]) / 2)
        tl_tr_center_y = int((corner[0][1] + corner[1][1]) / 2)

        cv2.line(image, center, (tl_tr_center_x, tl_tr_center_y), (255, 0, 0), 5)
        display_offset = int(math.sqrt((tl_tr_center_x - center[0]) ** 2 + (tl_tr_center_y - center[1]) ** 2))
        cv2.putText(image, str(ids), (center[0] + int(display_offset / 2), center[1]),
                    cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
        angle = details[1]
        # cv2.putText(image, str(angle), (center[0]-display_offset, center[1]), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 255, 0), 2)
    return image

def send_next_array(sock, all_arrays, current_array_index):
    # Increment the current array index
    current_array_index = (current_array_index + 1) % len(all_arrays)

    # Send the next array
    array_to_send = all_arrays[current_array_index]
    sock.send(str(array_to_send).encode())

    print(f"Sent array: {array_to_send}")

    return current_array_index


def detect_ArUco_details(image):
    ArUco_details_dict = {}
    ArUco_corners = {}

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    aruco_dict = aruco.getPredefinedDictionary(aruco.DICT_4X4_1000)
    aruco_detector = aruco.ArucoDetector(aruco_dict)
    parameters = aruco.DetectorParameters()

    parameters.minMarkerPerimeterRate = 0.001
    aruco_detector.setDetectorParameters(parameters)

    corners, ids, _ = aruco_detector.detectMarkers(gray)

    if ids is not None:
        for i in range(len(ids)):
            marker_id = int(ids[i][0])
            c = corners[i][0]
            center_x = int((c[0][0] + c[2][0]) / 2)
            center_y = int((c[0][1] + c[2][1]) / 2)

            angle_rad = math.atan2(c[1][1] - c[0][1], c[1][0] - c[0][0])
            angle_deg = math.degrees(angle_rad)
            angle_deg = -angle_deg

            ArUco_details_dict[marker_id] = [[center_x, center_y], int(angle_deg)]
            ArUco_corners[marker_id] = np.array(c)

    return ArUco_details_dict, ArUco_corners

def qgis_ArUco_image(image, ArUco_details_dict, ArUco_corners, target_id, data_dict, circle_radius=100):
    if target_id not in ArUco_details_dict:
        print(f"Target ID {target_id} not found in the current frame.")
        return image

    target_center = np.array(ArUco_details_dict[target_id][0])

    for ids, details in ArUco_details_dict.items():
        center = details[0]
        if ids == target_id:
            cv2.circle(image, tuple(target_center), circle_radius, (0, 255, 0), 2)

    nearest_id = None
    nearest_distance = float('inf')

    for ids, details in ArUco_details_dict.items():
        if ids != target_id:
            distance = np.linalg.norm(np.array(details[0]) - target_center)
            if distance < nearest_distance and distance <= circle_radius:
                nearest_id = ids
                nearest_distance = distance

    if nearest_id is not None:
        print(f"The nearest ArUco ID to {target_id} within the circle is {nearest_id} with a distance of {nearest_distance:.2f}")

        if nearest_id in data_dict:
            print(f"Found corresponding data for ArUco ID {nearest_id}: {data_dict[nearest_id]}")

            write_to_csv([data_dict[nearest_id]])

    return image

def write_to_csv(data, filename='newqgis.csv'):
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = ['lat', 'lon']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()
        for item in data:
            writer.writerow({'lat': item[0], 'lon': item[1]})


if __name__ == "__main__":
    df = pd.read_csv(r"C:\Users\Lenovo\identified_labels.csv")
    data_dict = {
        23: (39.6128542, -74.3629792),
        24: (39.6130113, -74.3629026),
        22: (39.6132182, -74.3628642),
        49: (39.6133943, -74.3628174),
        50: (39.61354, -74.3627608),
        51: (39.6137546, -74.3626727),
        52: (39.6139079, -74.3626152),
        53: (39.6139539, -74.3625615),
        54: (39.6139424, -74.362393),
        48: (39.613904, -74.3621746),
        47: (39.6138389, -74.3619025),
        46: (39.6137947, -74.3617297),
        45: (39.6137623, -74.3615538),
        44: (39.6137163, -74.3613354),
        43: (39.6136473, -74.3610787),
        10: (39.6134711, -74.3609714),
        8: (39.6133025, -74.3610366),
        12: (39.6131799, -74.3610826),
        9: (39.6130458, -74.3611247),
        11: (39.6129078, -74.3611592),
        13: (39.6127776, -74.3612473),
        14: (39.6126818, -74.3612875),
        15: (39.6126473, -74.3613565),
        16: (39.612632, -74.3614983),
        17: (39.6126933, -74.3616784),
        18: (39.6127316, -74.3618814),
        19: (39.6127546, -74.3620845),
        20: (39.6128235, -74.3623451),
        21: (39.6128389, -74.3625328),
        25: (39.6131607, -74.3626612),
        26: (39.6131416, -74.3625156),
        27: (39.6130956, -74.3622359),
        28: (39.6130036, -74.3618029),
        29: (39.6129155, -74.3613393),
        34: (39.6134519, -74.3624428),
        33: (39.6133906, -74.3621286),
        32: (39.6133638, -74.3619102),
        31: (39.6132795, -74.3616113),
        30: (39.6132067, -74.3612588),
        42: (39.6137086, -74.3625539),
        41: (39.6136818, -74.3624121),
        40: (39.6136358, -74.3621937),
        39: (39.6135745, -74.3619255),
        35: (39.6135285, -74.3617148),
        38: (39.6135056, -74.3615692),
        37: (39.6134481, -74.3613048),
        36: (39.6134136, -74.3611668),
    }

    array_ids_list, priority_dictionary = get_array_ids_list(df)
    all_arrays = get_all_arrays(priority_dictionary)

    cap = cv2.VideoCapture(0)
    width = 1920
    height = 1080
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    mark_ids = [4, 5, 6, 7,48,34,31,29,21]

    marker = 'aruco'
    all_ids = array_ids_list
    current_array_index = 0

    desired_id_index = 0
    desired_id = all_ids[desired_id_index]
    radius = 200

    ESP32_IP = "192.168.50.254"
    ESP32_PORT = 12345
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((ESP32_IP, ESP32_PORT))

    array_to_send = all_arrays[current_array_index]
    sock.send(str(array_to_send).encode())
    print(f"Sent array: {array_to_send}")

    while True:
        ret, frame = cap.read()

        if not ret:
            print("Error reading frame from camera")
            break

        ArUco_details_dict, ArUco_corners = detect_ArUco_details(frame)

        marked_frame = mark_ArUco_image(frame, ArUco_details_dict, ArUco_corners, desired_id, all_ids)
        qgis_frame = qgis_ArUco_image(frame, ArUco_details_dict, ArUco_corners, bot_aruco_id, data_dict, circle_radius=100)

        target_ids = [4, 5, 6, 7]
        valid_ids = [id for id in target_ids if id in ArUco_details_dict]

        if valid_ids:
            # Extract the region of interest (ROI) containing the markers
            roi_corners = np.concatenate([ArUco_corners[id] for id in valid_ids], axis=0)
            x, y, w, h = cv2.boundingRect(roi_corners)
            roi = marked_frame[y:y+h, x:x+w]

            # Display the ROI
            cv2.imshow('ArUco ROI', roi)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        if bot_aruco_id in ArUco_details_dict:
            center = ArUco_details_dict[bot_aruco_id][0]

            if desired_id in ArUco_details_dict:
                desired_center = ArUco_details_dict[desired_id][0]
                angle_rad = math.atan2(desired_center[1] - center[1], desired_center[0] - center[0])
                line_angle_deg = math.degrees(angle_rad)

                if radius > math.sqrt((desired_center[0] - center[0]) ** 2 + (desired_center[1] - center[1]) ** 2):
                    stop_conditions = {
                        48: (22, 55),
                        34: (5, 90),
                        31: (45,90),
                        29: (20, 90),
                        21: (25, 50)
                    }
                    if desired_id in stop_conditions:
                        angle_range = stop_conditions[desired_id]
                        if angle_range[0] <= line_angle_deg <= angle_range[1]:
                            array_zero = [0]
                            sock.send(str(array_zero).encode())
                            print(f"Sent array: {array_zero}")
                            # Call the function to send the next array
                            time.sleep(2)
                            current_array_index = (current_array_index + 1) % len(all_arrays)
                            array_to_send = all_arrays[current_array_index]
                            sock.send(str(array_to_send).encode())
                            print(f"Sent array: {array_to_send}")

                            desired_id_index = (desired_id_index + 1) % len(all_ids)
                            desired_id = all_ids[desired_id_index]

    cap.release()
    cv2.destroyAllWindows()
    sock.close()
"""
* Team Id: GG_1231
* Author List: YUWINGANESH K S , VIJAY ANAND M , GOWRISHANGAR I R , VIGNESHRAM R
* Filename: COMMUNICATION
* Theme: Geo Guide 
* Functions: find_most_frequent_event, get_array_ids_list, get_all_arrays, mark_ArUco_image, send_next_array, detect_ArUco_details, qgis_ArUco_image, write_to_csv, calculate_dynamic_distance, qgis_thread_function
* Global Variables: bot_aruco_id
"""

import numpy as np
import cv2
from cv2 import aruco
import math
import time
import socket
import pandas as pd
import csv
import threading

bot_aruco_id = 100

"""
    * Function Name: find_most_frequent_event
    * Input: column (pandas Series) - A column of data representing events
    * Output: String - The most frequent event in the column
    * Logic: This function takes a pandas Series representing events as input. It calculates the frequency of each event
      excluding the "unknown" events, and returns the most frequent event. If there are no non-"unknown" events, it 
      returns "unknown".
    * Example Call: most_frequent_event = find_most_frequent_event(df[column])
"""

def find_most_frequent_event(column):
    event_counts = column[column != "unknown"].value_counts()
    if len(event_counts) > 0:
        return event_counts.idxmax()
    else:
        return "unknown"

"""
    * Function Name: get_array_ids_list
    * Input: df (pandas DataFrame) - DataFrame containing event data
    * Output: Tuple (List, Dictionary) - A tuple containing a list of array IDs and a dictionary mapping array IDs to events
    * Logic: This function processes a pandas DataFrame containing event data. It iterates through each column to find the
      most frequent event for each array. It then generates a list of array IDs based on the priority order defined in the 
      code. Additionally, it constructs a dictionary mapping array IDs to events. The function returns the list of array IDs
      and the dictionary.
    * Example Call: array_ids_list, priority_dictionary = get_array_ids_list(df)
"""

def get_array_ids_list(df):
    newdict = {}
    for column in df.columns[0:]:
        most_frequent_event = find_most_frequent_event(df[column])
        newdict[column] = most_frequent_event

    priority_order = ["fire", "destroyed_buildings", "human_aid_rehabilitation", "military_vehicles", "combat", "blank"]
    priority_list = sorted(newdict.values(), key=lambda x: priority_order.index(x))
    bot_list = [value for value in priority_list if value != "blank"]

    priority_dictionary = {}
    for event in bot_list:
        for key, value in newdict.items():
            if value == event:
                priority_dictionary[key] = value
                break

    event_to_array_id = {'A': 21, 'B': 29, 'C': 31, 'D': 34, 'E': 48}

    priority_dictionary_with_array_ids = {}
    for key, value in priority_dictionary.items():
        array_id = event_to_array_id[key]
        priority_dictionary_with_array_ids[key] = {'array_id': array_id, 'event': value}

    array_ids_list = [entry['array_id'] for entry in priority_dictionary_with_array_ids.values()]
   
    return array_ids_list, priority_dictionary

"""
    * Function Name: get_all_arrays
    * Input: priority_dictionary (Dictionary) - Dictionary mapping array IDs to events
    * Output: List - A list containing arrays corresponding to the events based on priority
    * Logic: This function generates arrays based on the priority of events provided in the priority_dictionary. It maps 
      events to predefined arrays and constructs arrays accordingly. The constructed arrays are returned as a list.
    * Example Call: all_arrays = get_all_arrays(priority_dictionary)
"""

def get_all_arrays(priority_dictionary):

    # Define the arrays
    SA = [2]
    SB = [1, 2, 1]
    SC = [1, 1, 2, 1]
    SD = [1, 1, 2]
    SE = [1, 1, 1, 1]

    AB = [3, 2]
    AC = [3, 1, 2]
    AD = [2, 1, 2]
    AE = [2,1,1,1]
    AS = [7]

    BA = [3,2]
    BC = [3,3]
    BD = [2,3]
    BE = [1,2,1,1]
    BS = [5,1,3,6]

    CA = [3,1,2]
    CB = [2,2]
    CD = [1]
    CE = [3,1]
    CS = [1,3,1,6]

    DA = [3,1,3]
    DB = [3,2]
    DC = [1]
    DE = [2,1]
    DS = [3,1,6]

    EA = [1,1,1,3]
    EB = [1,1,3]
    EC = [1,3]
    ED = [1,3]
    ES = [1,1,1,6]


    array_mapping = {
        "A": SA, "B": SB, "C": SC, "D": SD, "E": SE,
        "AB": AB, "AC": AC, "AD": AD, "AE": AE, "AS" : AS,
        "BA": BA, "BC": BC, "BD": BD, "BE": BE, "BS": BS,
        "CA": CA, "CB": CB, "CD": CD, "CE": CE, "CS": CS,
        "DA": DA, "DB": DB, "DC": DC, "DE": DE, "DS": DS,
        "EA": EA, "EB": EB, "EC": EC, "ED": ED, "ES": ES,
    }

    new_priority_dict = {}
    keys = list(priority_dictionary.keys())
    for i in range(len(keys)):
        if i == 0:
            new_priority_dict[keys[i]] = priority_dictionary[keys[i]]
        else:
            new_priority_dict[keys[i-1] + keys[i]] = priority_dictionary[keys[i]]

    pre_final_array = list(priority_dictionary.keys())
    pre_final_array[-1] += "S"

    final_array = []
    final_array.insert(len(final_array), pre_final_array[-1])

    new_arr = list(new_priority_dict.keys())
    new_arr.extend(final_array)

    all_arrays = [array_mapping[key] for key in new_arr]
    return all_arrays

"""
    * Function Name: mark_ArUco_image
    * Input: 
        - image (numpy array): Input image
        - ArUco_details_dict (dictionary): Dictionary containing ArUco marker IDs as keys and their corresponding details as values
        - ArUco_corners (dictionary): Dictionary containing ArUco marker IDs as keys and their corresponding corner points as values
        - desired_id (int): The desired ArUco marker ID
        - all_ids (list): List of all ArUco marker IDs
    * Output: None
    * Logic: 
        - Draws circles around detected ArUco markers on the input image.
        - Draws a circle around the bot's ArUco marker (bot_aruco_id) with a specified radius.
        - Draws a line connecting the center of the bot's ArUco marker to the center of the desired ArUco marker.
        - Calculates and displays the angle (in degrees) between the line connecting the bot's ArUco marker and the desired ArUco marker and the x-axis.
    * Example Call: 
        mark_ArUco_image(image, ArUco_details_dict, ArUco_corners, desired_id, all_ids)
"""

def mark_ArUco_image(image, ArUco_details_dict, ArUco_corners, desired_id, all_ids):
    for ids, details in ArUco_details_dict.items():
        center = details[0]
        cv2.circle(image, center, 5, (0, 0, 255), -1)

        if ids == bot_aruco_id:
            # Draw circle around ID 100
            radius = 230  # Set the radius of the circle
            cv2.circle(image, center, radius, (0, 255, 0), 2)

            # Draw line from center of ID 100 to the center of the desired ID
            if desired_id in ArUco_details_dict:
                desired_center = ArUco_details_dict[desired_id][0]
                cv2.line(image, center, tuple(desired_center), (255, 0, 0), 5)
                # Calculate the angle of the line (in degrees) using atan2
                angle_rad = math.atan2(desired_center[1] - center[1], desired_center[0] - center[0])
                angle_deg = math.degrees(angle_rad)
                # Display the angle
                distance = math.sqrt((desired_center[0] - center[0]) ** 2 + (desired_center[1] - center[1]) ** 2)
                cv2.putText(image, f"Angle: {angle_deg:.2f} | Distance: {distance:.2f}", (center[0], center[1] - 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
           
        corner = ArUco_corners[int(ids)]
        cv2.circle(image, (int(corner[0][0]), int(corner[0][1])), 3, (50, 50, 50), -1)
        cv2.circle(image, (int(corner[1][0]), int(corner[1][1])), 3, (0, 255, 0), -1)
        cv2.circle(image, (int(corner[2][0]), int(corner[2][1])), 3, (128, 0, 255), -1)
        cv2.circle(image, (int(corner[3][0]), int(corner[3][1])), 3, (25, 255, 255), -1)

        tl_tr_center_x = int((corner[0][0] + corner[1][0]) / 2)
        tl_tr_center_y = int((corner[0][1] + corner[1][1]) / 2)

        cv2.line(image, center, (tl_tr_center_x, tl_tr_center_y), (255, 0, 0), 5)
        display_offset = int(math.sqrt((tl_tr_center_x - center[0]) ** 2 + (tl_tr_center_y - center[1]) ** 2))
        cv2.putText(image, str(ids), (center[0] + int(display_offset / 2), center[1]),
                    cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
        angle = details[1]
        cv2.putText(image, str(angle), (center[0]-display_offset, center[1]), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 2)

"""
    * Function Name: send_next_array
    * Input: 
        - sock (socket object) - Socket object for communication
        - all_arrays (list) - List of arrays to send
        - current_array_index (int) - Index of the current array in the list
    * Output: 
        - int - Updated index of the current array
    * Logic: 
        This function increments the current array index by 1 and sends the next array via the provided socket. 
        It uses modular arithmetic to ensure that the index wraps around when it reaches the end of the list.
    * Example Call: 
        current_array_index = send_next_array(sock, all_arrays, current_array_index)
"""

def send_next_array(sock, all_arrays, current_array_index):
    # Increment the current array index
    current_array_index = (current_array_index + 1) % len(all_arrays)

    # Send the next array
    array_to_send = all_arrays[current_array_index]
    sock.send(str(array_to_send).encode())

    print(f"Sent array: {array_to_send}")

    return current_array_index

"""
    * Function Name: detect_ArUco_details
    * Input: image (numpy array) - Image containing ArUco markers
    * Output: 
        - ArUco_details_dict (dictionary) - Dictionary mapping marker IDs to their details
        - ArUco_corners (dictionary) - Dictionary mapping marker IDs to their corner coordinates
    * Logic: 
        This function detects ArUco markers in the provided image using OpenCV. It extracts marker IDs, corner 
        coordinates, center coordinates, and orientation angles for each marker. The details are stored in 
        dictionaries and returned.
    * Example Call: 
        ArUco_details, ArUco_corners = detect_ArUco_details(image)
"""

def detect_ArUco_details(image):
    ArUco_details_dict = {}
    ArUco_corners = {}

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    aruco_dict = aruco.getPredefinedDictionary(aruco.DICT_4X4_1000)
    aruco_detector = aruco.ArucoDetector(aruco_dict)
    parameters = aruco.DetectorParameters()

    parameters.minMarkerPerimeterRate = 0.001
    aruco_detector.setDetectorParameters(parameters)

    corners, ids, _ = aruco_detector.detectMarkers(gray)

    if ids is not None:
        for i in range(len(ids)):
            marker_id = int(ids[i][0])
            c = corners[i][0]
            center_x = int((c[0][0] + c[2][0]) / 2)
            center_y = int((c[0][1] + c[2][1]) / 2)

            angle_rad = math.atan2(c[1][1] - c[0][1], c[1][0] - c[0][0])
            angle_deg = math.degrees(angle_rad)
            angle_deg = -angle_deg

            ArUco_details_dict[marker_id] = [[center_x, center_y], int(angle_deg)]
            ArUco_corners[marker_id] = np.array(c)

    return ArUco_details_dict, ArUco_corners

"""
    * Function Name: qgis_ArUco_image
    * Input: 
        - image (numpy array) - Input image
        - ArUco_details_dict (dictionary) - Dictionary mapping marker IDs to their details
        - ArUco_corners (dictionary) - Dictionary mapping marker IDs to their corner coordinates
        - target_id (int) - Target ArUco marker ID
        - data_dict (dictionary) - Dictionary containing data corresponding to ArUco IDs
        - circle_radius (int) - Radius of the circle for visualization (default is 100)
    * Output: 
        - image (numpy array) - Image with visualizations
    * Logic: 
        This function visualizes ArUco markers on the input image. It highlights the target marker with a circle 
        and finds the nearest marker within a specified radius. If a nearest marker is found, it displays the 
        corresponding data and writes it to a CSV file.
    * Example Call: 
        output_image = qgis_ArUco_image(image, ArUco_details_dict, ArUco_corners, target_id, data_dict)
"""

def qgis_ArUco_image(image, ArUco_details_dict, ArUco_corners, target_id, data_dict, circle_radius=100):
    if target_id not in ArUco_details_dict:
        print(f"Target ID {target_id} not found in the current frame.")
        return  # Exit the function if the target ID is not found

    target_center = np.array(ArUco_details_dict[target_id][0])

    for ids, details in ArUco_details_dict.items():
        center = details[0]
        if ids == target_id:
            cv2.circle(image, tuple(target_center), circle_radius, (0, 255, 0), 2)

    nearest_id = None
    nearest_distance = float('inf')

    for ids, details in ArUco_details_dict.items():
        if ids != target_id:
            distance = np.linalg.norm(np.array(details[0]) - target_center)
            if distance < nearest_distance and distance <= circle_radius:
                nearest_id = ids
                nearest_distance = distance

    if nearest_id is not None:
        #print(f"The nearest ArUco ID to {target_id} within the circle is {nearest_id} with a distance of {nearest_distance:.2f}")

        if nearest_id in data_dict:
            #print(f"Found corresponding data for ArUco ID {nearest_id}: {data_dict[nearest_id]}")

            write_to_csv([data_dict[nearest_id]])

    return image

"""
    * Function Name: write_to_csv
    * Input: 
        - data (list) - List of data to write to CSV
        - filename (str) - Name of the CSV file (default is 'qgis.csv')
    * Output: None
    * Logic: 
        This function writes data to a CSV file. It takes a list of data as input and writes it row by row 
        to the specified CSV file.
    * Example Call: 
        write_to_csv(data)
"""

def write_to_csv(data, filename='qgis.csv'):
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = ['lat', 'lon']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()
        for item in data:
            writer.writerow({'lat': item[0], 'lon': item[1]})

"""
    * Function Name: calculate_dynamic_distance
    * Input: desired_id (int) - ID for which dynamic distance needs to be calculated
    * Output: int - Dynamic distance corresponding to the desired ID
    * Logic: 
        This function calculates dynamic distances based on predefined mappings for different IDs. If the desired 
        ID is found in the mapping, it returns the corresponding distance; otherwise, it returns a default distance.
    * Example Call: 
        distance = calculate_dynamic_distance(desired_id)
"""

def calculate_dynamic_distance(desired_id):
    # Define desired distances for different IDs
    distance_mapping = {
        48: 230,
        34: 230,
        31: 200,
        29: 200,
        21: 220
        # Add more ID-distance mappings as needed
    }

    # Check if the desired_id is in the mapping, otherwise use a default distance
    return distance_mapping.get(desired_id, 200) 

"""
* Function Name: qgis_thread_function
* Input: None
* Output: None
* Logic: 
    - This function runs in a separate thread to continuously process frames from the camera.
    - It retrieves frames from the camera using the VideoCapture object and checks if the frame is successfully read.
    - If the frame is not successfully read, it prints an error message and breaks the loop.
    - It detects ArUco markers in the frame and retrieves their details and corners.
    - Then, it calls the qgis_ArUco_image function to generate a QGIS-compatible image with ArUco markers highlighted.
    - The circle_radius parameter specifies the size of circles to draw around the detected markers.
    - This function runs indefinitely, continuously processing frames until the program is terminated.
* Example Call: 
    - This function is automatically invoked when it is defined and the thread starts running.
    - It can be called as part of the main program logic where threading for camera processing is initiated.
"""
def qgis_thread_function():
        while True:
            ret, frame = cap.read()

            if not ret:
                print("Error reading frame from camera")
                break

            ArUco_details_dict, ArUco_corners = detect_ArUco_details(frame)
            qgis_frame = qgis_ArUco_image(frame, ArUco_details_dict, ArUco_corners, bot_aruco_id, data_dict, circle_radius=100)


"""
* Function Name: main
* Input: None
* Output: None
* Logic: 
    - Reads data from a CSV file containing identified labels and sets up marker coordinates.
    - Initializes necessary components like video capture, socket connection, and marker detection.
    - Sends initial data through the socket connection and starts a separate thread for QGIS processing.
    - Enters a main loop for continuous marker detection and action based on detected markers.
    - Handles special cases for marker positions and angles to determine the array to send to the ESP32 board.
    - Releases resources like video capture, closes windows, and closes the socket connection.
    - Key decision-making occurs based on marker positions and angles, ensuring efficient robot movement.
    - Robust error handling is implemented to manage potential failures in reading frames or socket connections.
    - The program flow is structured to ensure smooth communication with the ESP32 board and accurate marker detection.
    - Real-time visualization of detected markers and regions of interest is provided for debugging and monitoring.
    - Proper comments and variable names are used to enhance code readability and maintainability.
    - The main function encapsulates the entire program's execution flow, providing a clear entry point for execution.
* Example Call: Automatically invoked when the script is run.
"""

if __name__ == "__main__":
    df = pd.read_csv(r"C:\Users\Lenovo\identified_labels6a.csv")
    data_dict = {
        23: (39.6128542, -74.3629792),
        24: (39.6130113, -74.3629026),
        22: (39.6132182, -74.3628642),
        49: (39.6133943, -74.3628174),
        50: (39.61354, -74.3627608),
        51: (39.6137546, -74.3626727),
        52: (39.6139079, -74.3626152),
        53: (39.6139539, -74.3625615),
        54: (39.6139424, -74.362393),
        48: (39.613904, -74.3621746),
        47: (39.6138389, -74.3619025),
        46: (39.6137947, -74.3617297),
        45: (39.6137623, -74.3615538),
        44: (39.6137163, -74.3613354),
        43: (39.6136473, -74.3610787),
        10: (39.6134711, -74.3609714),
        8: (39.6133025, -74.3610366),
        12: (39.6131799, -74.3610826),
        9: (39.6130458, -74.3611247),
        11: (39.6129078, -74.3611592),
        13: (39.6127776, -74.3612473),
        14: (39.6126818, -74.3612875),
        15: (39.6126473, -74.3613565),
        16: (39.612632, -74.3614983),
        17: (39.6126933, -74.3616784),
        18: (39.6127316, -74.3618814),
        19: (39.6127546, -74.3620845),
        20: (39.6128235, -74.3623451),
        21: (39.6128389, -74.3625328),
        25: (39.6131607, -74.3626612),
        26: (39.6131416, -74.3625156),
        27: (39.6130956, -74.3622359),
        28: (39.6130036, -74.3618029),
        29: (39.6129155, -74.3613393),
        34: (39.6134519, -74.3624428),
        33: (39.6133906, -74.3621286),
        32: (39.6133638, -74.3619102),
        31: (39.6132795, -74.3616113),
        30: (39.6132067, -74.3612588),
        42: (39.6137086, -74.3625539),
        41: (39.6136818, -74.3624121),
        40: (39.6136358, -74.3621937),
        39: (39.6135745, -74.3619255),
        35: (39.6135285, -74.3617148),
        38: (39.6135056, -74.3615692),
        37: (39.6134481, -74.3613048),
        36: (39.6134136, -74.3611668),
    }

    array_ids_list, priority_dictionary = get_array_ids_list(df)
    all_arrays = get_all_arrays(priority_dictionary)

    cap = cv2.VideoCapture(0)
    width = 1920
    height = 1080
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    mark_ids = [4, 5, 6, 7,48,34,31,29,21]

    marker = 'aruco'
    all_ids = array_ids_list
    current_array_index = 0
    all_ids.append(23)

    desired_id_index = 0
    desired_id = all_ids[desired_id_index]
    radius = 230

    ESP32_IP = "192.168.169.254"
    ESP32_PORT = 12345
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((ESP32_IP, ESP32_PORT))

    array_to_send = all_arrays[current_array_index]
    sock.send(str(array_to_send).encode())
    print(f"Sent array: {array_to_send}")

    qgis_thread = threading.Thread(target=qgis_thread_function)
    qgis_thread.start()

    while True:
        ret, frame = cap.read()

        if not ret:
            print("Error reading frame from camera")
            break

        ArUco_details_dict, ArUco_corners = detect_ArUco_details(frame)

        marked_frame = mark_ArUco_image(frame, ArUco_details_dict, ArUco_corners, desired_id, all_ids)
        #qgis_frame = qgis_ArUco_image(frame, ArUco_details_dict, ArUco_corners, bot_aruco_id, data_dict, circle_radius=100)

        target_ids = [4, 5, 6, 7]
        valid_ids = [id for id in target_ids if id in ArUco_details_dict]

        if valid_ids:
            # Extract the region of interest (ROI) containing the markers
            roi_corners = np.concatenate([ArUco_corners[id] for id in valid_ids], axis=0)
            x, y, w, h = cv2.boundingRect(roi_corners)
            roi = frame[y:y+h, x:x+w]

            # Display the ROI
            cv2.imshow('ArUco ROI', roi)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        if bot_aruco_id in ArUco_details_dict:
            center = ArUco_details_dict[bot_aruco_id][0]
            bot_angle = ArUco_details_dict[bot_aruco_id][1]


            if desired_id in ArUco_details_dict:
                desired_center = ArUco_details_dict[desired_id][0]
                angle_rad = math.atan2(desired_center[1] - center[1], desired_center[0] - center[0])
                line_angle_deg = math.degrees(angle_rad)
                distance = math.sqrt((desired_center[0] - center[0]) ** 2 + (desired_center[1] - center[1]) ** 2)

                dynamic_desired_distance = calculate_dynamic_distance(desired_id)

                if distance <= dynamic_desired_distance:
                    stop_conditions = {
                        48: (12, 100),
                        34: (10, 90),
                        31: (75, 90),
                        29: (13, 90),
                        21: (7, 90)
                    }
                    if bot_aruco_id in ArUco_details_dict:
                        center = ArUco_details_dict[bot_aruco_id][0]
                        bot_angle = ArUco_details_dict[bot_aruco_id][1]

                        if desired_id in ArUco_details_dict:
                            desired_center = ArUco_details_dict[desired_id][0]
                            angle_rad = math.atan2(desired_center[1] - center[1], desired_center[0] - center[0])
                            line_angle_deg = math.degrees(angle_rad)
                            distance = math.sqrt((desired_center[0] - center[0]) ** 2 + (desired_center[1] - center[1]) ** 2)

                            dynamic_desired_distance = calculate_dynamic_distance(desired_id)

                            if distance <= dynamic_desired_distance:
                                stop_conditions = {
                                    48: (12, 100),
                                    34: (10, 90),
                                    31: (75, 90),
                                    29: (13, 90),
                                    21: (7, 90)
                                }
                                if desired_id in stop_conditions:
                                    angle_range = stop_conditions[desired_id]
                                    if angle_range[0] <= line_angle_deg <= angle_range[1]:
                                        next_desired_id_index = (desired_id_index + 1) % len(all_ids)
                                        next_desired_id = all_ids[next_desired_id_index]

                                        if (desired_id in [21, 34, 48]) and (next_desired_id in [21, 34, 48]):
                                            if bot_angle < 0:
                                                array_to_send = [9]  # Send 9 before the main array if bot angle is negative and next desired ID is also in [21, 34, 48]
                                            else:
                                                array_to_send = [0] 

                                            # Send the array
                                            sock.send(str(array_to_send).encode())
                                            print(f"Sent array: {array_to_send}")

                                            # If array_to_send was [9], send the next array after reaching the desired position
                                            if array_to_send == [9] or array_to_send == [0] :
                                                # Wait for some time (adjust as needed) to allow the bot to reach the desired position
                                                time.sleep(1)  # Example: Wait for 5 seconds
                                                
                                                # Send the next array after reaching the desired position
                                                current_array_index = (current_array_index + 1) % len(all_arrays)
                                                array_to_send = all_arrays[current_array_index] 
                                                sock.send(str(array_to_send).encode())
                                                print(f"Sent next array: {array_to_send}")  

                                            desired_id_index = (desired_id_index + 1) % len(all_ids)
                                            desired_id = all_ids[desired_id_index]  

                                        elif (desired_id in [21, 34, 48]) and (next_desired_id in [29, 31]):
                                            if bot_angle < 0:
                                                array_to_send = [0]  
                                            else:
                                                array_to_send = [9]  # Send 9 before the main array if bot angle is positive and next desired ID is in [29, 31]

                                            # Send the array
                                            sock.send(str(array_to_send).encode())
                                            print(f"Sent array: {array_to_send}")

                                            # If array_to_send was [9], send the next array after reaching the desired position
                                            if array_to_send == [9] or array_to_send == [0]:
                                                # Wait for some time (adjust as needed) to allow the bot to reach the desired position
                                                time.sleep(1)  # Example: Wait for 5 seconds
                                                
                                                # Send the next array after reaching the desired position
                                                current_array_index = (current_array_index + 1) % len(all_arrays)
                                                array_to_send = all_arrays[current_array_index] 
                                                sock.send(str(array_to_send).encode())
                                                print(f"Sent next array: {array_to_send}")  
                                            desired_id_index = (desired_id_index + 1) % len(all_ids)
                                            desired_id = all_ids[desired_id_index]

                                        elif (desired_id in [29, 31]) and (next_desired_id in [29, 31]):
                                            if bot_angle < 0:
                                                array_to_send = [0]  
                                            else:
                                                array_to_send = [9]  # Send 9 before the main array if bot angle is positive and next desired ID is also in [29, 31]

                                            # Send the array
                                            sock.send(str(array_to_send).encode())
                                            print(f"Sent array: {array_to_send}")

                                            # If array_to_send was [9], send the next array after reaching the desired position
                                            if array_to_send == [9] or array_to_send == [0]:
                                                # Wait for some time (adjust as needed) to allow the bot to reach the desired position
                                                time.sleep(1)  # Example: Wait for 5 seconds
                                                
                                                # Send the next array after reaching the desired position
                                                current_array_index = (current_array_index + 1) % len(all_arrays)
                                                array_to_send = all_arrays[current_array_index] 
                                                sock.send(str(array_to_send).encode())
                                                print(f"Sent next array: {array_to_send}")   
                                            desired_id_index = (desired_id_index + 1) % len(all_ids)
                                            desired_id = all_ids[desired_id_index]
                                                

                                        elif (desired_id in [29, 31]) and (next_desired_id in [21, 34, 48]):
                                            if bot_angle < 0:
                                                array_to_send = [0]  
                                            else:
                                                array_to_send = [0]  


                                            # Send the array
                                            sock.send(str(array_to_send).encode())
                                            print(f"Sent array: {array_to_send}")

                                            # If array_to_send was [9], send the next array after reaching the desired position
                                            if array_to_send == [9] or array_to_send == [0]:
                                                # Wait for some time (adjust as needed) to allow the bot to reach the desired position
                                                time.sleep(1)  # Example: Wait for 5 seconds

                                                # Send the next array after reaching the desired position
                                                current_array_index = (current_array_index + 1) % len(all_arrays)
                                                array_to_send = all_arrays[current_array_index] 
                                                sock.send(str(array_to_send).encode())
                                                print(f"Sent next array: {array_to_send}") 

                                            desired_id_index = (desired_id_index + 1) % len(all_ids)
                                            desired_id = all_ids[desired_id_index]

                                        else:
                                            array_to_send = get_all_arrays(priority_dictionary)  # Default case, send the main array

                                            if bot_angle < 0:
                                                array_to_send = [0]  
                                            else:
                                                array_to_send = [0]    

                                            # Send the array
                                            sock.send(str(array_to_send).encode())
                                            print(f"Sent array: {array_to_send}")

                                            # If array_to_send was [9], send the next array after reaching the desired position
                                            if array_to_send == [9] or array_to_send == [0]:
                                                # Wait for some time (adjust as needed) to allow the bot to reach the desired position
                                                time.sleep(1)  # Example: Wait for 5 seconds

                                                # Send the next array after reaching the desired position
                                                current_array_index = (current_array_index + 1) % len(all_arrays)
                                                array_to_send = all_arrays[current_array_index] 
                                                sock.send(str(array_to_send).encode())
                                                print(f"Sent next array: {array_to_send}") 
                                                
                                            desired_id_index = (desired_id_index + 1) % len(all_ids)
                                            desired_id = all_ids[desired_id_index]   
    cap.release()
    cv2.destroyAllWindows()
    sock.close()
"""
* Team Id: GG_1231
* Author List: YUWINGANESH K S , VIJAY ANAND M , GOWRISHANGAR I R , VIGNESHRAM R
* Filename: EVENT_DETECTION
* Theme: Geo Guide 
* Functions: save_to_csv, detect_ArUco_details, event_identification, classify_event, is_clear_frame, task_4a_return
* Global Variables: event_list, detected_list, combat, rehab, military_vehicles, fire, destroyed_building, Blank, model
"""

import cv2
import numpy as np
from tensorflow.keras.models import load_model
import math
import time
import sys
import csv

# DECLARING VARIABLES (DO NOT CHANGE/REMOVE THESE VARIABLES)
event_list = []
detected_list = []

combat = "combat"
rehab = "human_aid_rehabilitation"
military_vehicles = "military_vehicles"
fire = "fire"
destroyed_building = "destroyed_buildings"
Blank = "Blank"

# Load the model outside the loop
model = load_model(r"C:\Users\yuwin\OneDrive\Desktop\testing\task_5\New folder\06.02.24.h5")

"""
* Function Name: save_to_csv
* Input: identified_labels (Dictionary) - Dictionary containing identified labels
* Output: None
* Logic: This function saves the identified labels to a CSV file specified by csv_file_path.
* Example Call: save_to_csv(identified_labels)
"""
def save_to_csv(identified_labels):
    # Specify the CSV file path
    csv_file_path = "identified_labels.csv"

    # Open the CSV file in write mode
    with open(csv_file_path, 'w', newline='') as csvfile:
        # Create a CSV writer object
        csv_writer = csv.writer(csvfile)

        # Write the data row
        csv_writer.writerow(identified_labels.keys())
        csv_writer.writerow(identified_labels.values())

"""
* Function Name: detect_ArUco_details
* Input: image (numpy array) - Input image containing ArUco markers, 
         ArUco_details_dict (Dictionary) - Dictionary to store ArUco marker details, 
         ArUco_corners (Dictionary) - Dictionary to store ArUco marker corner coordinates
* Output: Tuple (Dictionary, Dictionary) - A tuple containing updated ArUco_details_dict and ArUco_corners
* Logic: This function detects ArUco markers in the input image, extracts their details, and updates the 
         dictionaries ArUco_details_dict and ArUco_corners with the detected information.
* Example Call: detect_ArUco_details(image, ArUco_details_dict, ArUco_corners)
"""
def detect_ArUco_details(image, ArUco_details_dict, ArUco_corners):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_1000)
    aruco_detector = cv2.aruco.ArucoDetector(aruco_dict)
    parameters = cv2.aruco.DetectorParameters()

    parameters.minMarkerPerimeterRate = 0.001
    aruco_detector.setDetectorParameters(parameters)

    corners, ids, _ = aruco_detector.detectMarkers(gray)

    if ids is not None:
        for i in range(len(ids)):
            marker_id = int(ids[i][0])
            c = corners[i][0]
            center_x = int((c[0][0] + c[2][0]) / 2)
            center_y = int((c[0][1] + c[2][1]) / 2)

            angle_rad = math.atan2(c[1][1] - c[0][1], c[1][0] - c[0][0])
            angle_deg = math.degrees(angle_rad)
            angle_deg = -angle_deg

            ArUco_details_dict[marker_id] = [[center_x, center_y], int(angle_deg)]
            ArUco_corners[marker_id] = np.array(c)

    return ArUco_details_dict, ArUco_corners

"""
* Function Name: event_identification
* Input: arena (numpy array) - Input image containing event regions, 
         min_contour_size (int) - Minimum contour size, 
         max_contour_size (int) - Maximum contour size, 
         confidence_threshold (float) - Confidence threshold, 
         bounding_box_scale (float) - Scaling factor for bounding box size
* Output: Tuple (Dictionary, numpy array) - A tuple containing identified labels and an annotated image with identified labels
* Logic: This function identifies events within the given image based on contours. It classifies each event region and assigns labels accordingly. 
         The identified labels and the annotated image with labels are returned.
* Example Call: event_identification(arena)
"""
def event_identification(arena, min_contour_size=5000, max_contour_size=12000, confidence_threshold=0.3, bounding_box_scale=0.8):
    time.sleep(1)
    llabe = {"A": '', "B": '', "C": '', "D": '', "E": ''}
    gray_image = cv2.cvtColor(arena, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray_image, 220, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=lambda c: cv2.boundingRect(c)[1] + cv2.boundingRect(c)[3], reverse=True)
    labels = iter(['A', 'B', 'C', 'D', 'E'])
    result_arena = arena.copy()

    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        contour_size = cv2.contourArea(contour)

        if min_contour_size < contour_size < max_contour_size:
            # Check if the contour size is within the desired range
            smaller_w = int(w * bounding_box_scale)
            smaller_h = int(h * bounding_box_scale)

            # Calculate the center of the original bounding box
            center_x = x + w // 2
            center_y = y + h // 2

            # Calculate the coordinates for the smaller bounding box
            new_x = max(0, center_x - smaller_w // 2)
            new_y = max(0, center_y - smaller_h // 2)

            cv2.rectangle(result_arena, (new_x, new_y), (new_x + smaller_w, new_y + smaller_h), (0, 255, 0), 2)

            event_region = arena[new_y:new_y + smaller_h, new_x:new_x + smaller_w]

            predicted_event, confidence = classify_event(event_region)

            time.sleep(1)

            if confidence > confidence_threshold:
                # Map predicted class index to event name
                if predicted_event == 0:
                    label_text = combat
                elif predicted_event == 1:
                    label_text = rehab
                elif predicted_event == 2:
                    label_text = military_vehicles
                elif predicted_event == 3:
                    label_text = fire
                elif predicted_event == 4:
                    label_text = destroyed_building
                elif predicted_event == 5:
                    label_text = Blank

                try:
                    label = next(labels)
                except StopIteration:
                    break

                cv2.putText(result_arena, f'{label_text}', (new_x, new_y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                            (0, 255, 0), 2)
                llabe[label] = str(label_text)

    return llabe, result_arena

"""
* Function Name: classify_event
* Input: event_image (numpy array) - Input image of the event region, confidence_threshold (float) - Confidence threshold
* Output: Tuple (int, float) - A tuple containing the predicted event and its confidence level
* Logic: This function classifies the given event image using a pre-trained model and returns the predicted event index and its confidence level.
* Example Call: classify_event(event_image)
"""
def classify_event(event_image, confidence_threshold=0.2):
    # Preprocess the event image to match the model's input requirements
    event_image = cv2.resize(event_image, (140, 140))  # Resize to (224, 224) pixels
    event_image = cv2.cvtColor(event_image, cv2.COLOR_BGR2RGB)  # Ensure 3 color channels

    # Normalize the image if necessary, according to the model's preprocessing

    # Make a prediction using the loaded model
    predictions = model.predict(event_image[np.newaxis, ...])

    # Extract class probabilities and predicted class index
    probabilities = predictions[0]
    predicted_class_index = np.argmax(probabilities)

    # Get the confidence level for the predicted class
    confidence = probabilities[predicted_class_index]

    # Map class label or index to an event name
    event = predicted_class_index

    # Return both the predicted event and its confidence level
    return event, confidence

"""
* Function Name: is_clear_frame
* Input: frame (numpy array) - Input frame from the camera, threshold (int) - Threshold value for brightness
* Output: bool - True if the frame is clear (above the threshold brightness), False otherwise
* Logic: This function checks whether the brightness of the input frame is above the specified threshold, indicating a clear frame.
* Example Call: is_clear_frame(frame)
"""
def is_clear_frame(frame, threshold=50):
    # Calculate the average brightness of the frame
    brightness = np.mean(frame)

    # Check if the brightness is above the threshold
    return brightness > threshold

"""
* Function Name: task_4a_return
* Input: None
* Output: Tuple (Dictionary, numpy array) - A tuple containing identified labels and an annotated image with identified labels
* Logic: This function captures a clear frame from the camera, detects ArUco markers, 
         identifies events in the frame, and returns the identified labels along with an annotated image.
* Example Call: task_4a_return()
"""
def task_4a_return():
    identified_labels = {}

    # Use the default camera (usually 0, but may be different depending on your setup)
    cap = cv2.VideoCapture(1)  # Change the camera index to 0 for the default camera

    cap.set(3, 1920)  # Width
    cap.set(4, 1080)  # Height

    if not cap.isOpened():
        print("Error: Could not open camera.")
        sys.exit()

    # Delay for camera stabilization
    #time.sleep(2)

    non_black_frames_to_capture = 10  # Adjust the number of frames to capture
    for _ in range(non_black_frames_to_capture):
        # Capture a frame from the camera
        ret, frame = cap.read()

        if ret and is_clear_frame(frame):
            break
        time.sleep(0.1)

    if not is_clear_frame(frame):
        print("Error: Unable to capture a clear frame.")
        sys.exit()

    # Add delay for ArUco detection
    time.sleep(1)
    ArUco_details_dict, ArUco_corners = detect_ArUco_details(frame, {}, {})
    target_ids = [4, 5, 6, 7]
    valid_ids = [id for id in target_ids if id in ArUco_details_dict]
    if valid_ids:
        # Extract the region of interest (ROI) containing the markers
        roi_corners = np.concatenate([ArUco_corners[id] for id in valid_ids], axis=0)
        x, y, w, h = cv2.boundingRect(roi_corners)
        roi = frame[y:y + h, x:x + w]
        identified_labels, are = event_identification(roi)

    # Filter out labels with 'Blank' values
    identified_labels = {label: value for label, value in identified_labels.items() if value != 'Blank'}

    cv2.destroyAllWindows()

    return identified_labels, are

"""
* Function Name: main
* Input: None
* Output: None
* Logic: 
    - Check if the script is being run as the main program.
    - Call the function task_4a_return() to perform event identification and obtain identified labels and processed arena image.
    - Print the identified labels for debugging or logging purposes.
    - Display the processed arena image with contours and labels for visualization.
    - Wait for a key press to close the window.
    - Save the identified labels to a CSV file for further analysis or logging.
* Example Call: Automatically invoked when the script is run.
"""

if __name__ == "__main__":
    identified_labels, are = task_4a_return()
    print(identified_labels)
    cv2.imshow('Image with Contours and Labels', are)
    cv2.waitKey(0)

    # Save to CSV
    save_to_csv(identified_labels)

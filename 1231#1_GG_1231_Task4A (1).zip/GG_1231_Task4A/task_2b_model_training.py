import os
import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import img_to_array, load_img
from sklearn.model_selection import train_test_split
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.applications.resnet50 import preprocess_input
from tensorflow.keras.optimizers import Adam

# Define the paths to the image folders
train_data_dir = r"C:\Users\Lenovo\Desktop\eyrc_dataset\train_data_dir"
valid_data_dir = r"C:\Users\Lenovo\Desktop\eyrc_dataset\train_data_dir" 

class_labels = ["combat", "humanitarianaid", "militaryvehicles", "fire", "destroyedbuilding"]
input_shape = (140, 140, 3)
base_model = tf.keras.applications.ResNet50(weights='imagenet', include_top=False, input_shape=input_shape)
x = tf.keras.layers.GlobalAveragePooling2D()(base_model.output)
output = tf.keras.layers.Dense(len(class_labels), activation='softmax')(x)
model = tf.keras.Model(inputs=base_model.input, outputs=output)
for layer in base_model.layers:
    layer.trainable = False

# Compile
optimizer = Adam()
model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])
X = []
y = []


for class_label in class_labels:
    label = class_labels.index(class_label)

    train_folder = os.path.join(train_data_dir, class_label)
    valid_folder = os.path.join(valid_data_dir, class_label)

    # Load training data
    for filename in os.listdir(train_folder)[:10000]:
        img_path = os.path.join(train_folder, filename)
        img = load_img(img_path, target_size=(140, 140))
        img_array = img_to_array(img)
        img_array = preprocess_input(img_array)

        X.append(img_array)
        y.append(label)

    # Load validation data
    for filename in os.listdir(valid_folder)[:10000]:
        img_path = os.path.join(valid_folder, filename)
        img = load_img(img_path, target_size=(140, 140))
        img_array = img_to_array(img)
        img_array = preprocess_input(img_array)

        X.append(img_array)
        y.append(label)

# Convert lists to arrays
X = np.array(X)
y = np.array(y)

y = tf.keras.utils.to_categorical(y, num_classes=len(class_labels))
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Training
num_epochs = 40
batch_size = 16

for epoch in range(num_epochs):
    print(f"Epoch {epoch+1}/{num_epochs}")
    indices = np.arange(len(X_train))
    np.random.shuffle(indices)
    X_train = X_train[indices]
    y_train = y_train[indices]
    train_loss = 0.0
    train_accuracy = 0.0
    num_batches = 0

    for i in range(0, len(X_train), batch_size):
        batch_images = X_train[i:i+batch_size]
        batch_labels = y_train[i:i+batch_size]

        with tf.GradientTape() as tape:
            logits = model(batch_images, training=True)
            loss_value = tf.keras.losses.categorical_crossentropy(batch_labels, logits)
            
        # Backward pass
        gradients = tape.gradient(loss_value, model.trainable_variables)
        model.optimizer.apply_gradients(zip(gradients, model.trainable_variables))

        train_loss += loss_value.numpy().mean()

        train_accuracy += np.mean(np.argmax(logits, axis=1) == np.argmax(batch_labels, axis=1))
        num_batches += 1

    train_loss /= num_batches
    train_accuracy /= num_batches

    val_loss = 0.0
    val_accuracy = 0.0
    num_batches = 0

    for i in range(0, len(X_test), batch_size):
        batch_images = X_test[i:i+batch_size]
        batch_labels = y_test[i:i+batch_size]

        logits = model(batch_images, training=False)
        loss_value = tf.keras.losses.categorical_crossentropy(batch_labels, logits)

        val_loss += loss_value.numpy().mean()
        val_accuracy += np.mean(np.argmax(logits, axis=1) == np.argmax(batch_labels, axis=1))
        num_batches += 1

    val_loss /= num_batches
    val_accuracy /= num_batches

    print(f"Train Loss: {train_loss:.4f}, Train Accuracy: {train_accuracy:.4f}")
    print(f"Val Loss: {val_loss:.4f}, Val Accuracy: {val_accuracy:.4f}")

# Save the trained model
model.save('ftask4trained_model33.h5')

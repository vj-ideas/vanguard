import numpy as np
import cv2
from cv2 import aruco
import math
import csv

def detect_ArUco_details(image):
    ArUco_details_dict = {}
    ArUco_corners = {} 

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    aruco_dict = aruco.getPredefinedDictionary(aruco.DICT_4X4_1000)
    aruco_detector = aruco.ArucoDetector(aruco_dict)
    parameters = aruco.DetectorParameters()

    parameters.minMarkerPerimeterRate = 0.001
    aruco_detector.setDetectorParameters(parameters)

    corners, ids, _ = aruco_detector.detectMarkers(gray)

    if ids is not None:
        for i in range(len(ids)):
            marker_id = int(ids[i][0])
            c = corners[i][0]
            center_x = int((c[0][0] + c[2][0]) / 2)
            center_y = int((c[0][1] + c[2][1]) / 2)

            angle_rad = math.atan2(c[1][1] - c[0][1], c[1][0] - c[0][0])
            angle_deg = math.degrees(angle_rad)
            angle_deg = -angle_deg

            ArUco_details_dict[marker_id] = [[center_x, center_y], int(angle_deg)]
            ArUco_corners[marker_id] = np.array(c)

    return ArUco_details_dict, ArUco_corners

def mark_ArUco_image(image, ArUco_details_dict, ArUco_corners, target_id, data_dict, circle_radius=50):
    if target_id not in ArUco_details_dict:
        print(f"Target ID {target_id} not found in the current frame.")
        return image

    target_center = np.array(ArUco_details_dict[target_id][0])

    for ids, details in ArUco_details_dict.items():
        center = details[0]
        if ids == target_id:
            cv2.circle(image, tuple(target_center), circle_radius, (0, 255, 0), 2)

    nearest_id = None
    nearest_distance = float('inf')

    for ids, details in ArUco_details_dict.items():
        if ids != target_id:
            distance = np.linalg.norm(np.array(details[0]) - target_center)
            if distance < nearest_distance and distance <= circle_radius:
                nearest_id = ids
                nearest_distance = distance

    if nearest_id is not None:
        print(f"The nearest ArUco ID to {target_id} within the circle is {nearest_id} with a distance of {nearest_distance:.2f}")

        if nearest_id in data_dict:
            print(f"Found corresponding data for ArUco ID {nearest_id}: {data_dict[nearest_id]}")

            write_to_csv([data_dict[nearest_id]])

    return image





def write_to_csv(data, filename='output.csv'):
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = ['lat', 'lon']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()
        for item in data:
            writer.writerow({'lat': item[0], 'lon': item[1]})

def main():
    cap = cv2.VideoCapture(1)

    if not cap.isOpened():
        print("Error: Unable to open the camera.")
        return
    
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

    #actual_fps = cap.get(cv2.CAP_PROP_FPS)
    #print(f"Actual Frame Rate: {actual_fps} fps")

    zoom_factor = 1.0
    translation_x = 0
    translation_y = 0
    target_id = 800  # Specify the target ID here
    data_dict = {
        23: (39.6128542, -74.3629792),
        24: (39.6130113, -74.3629026),
        22: (39.6132182, -74.3628642),
        49: (39.6133943, -74.3628174),
        50: (39.61354, -74.3627608),
        51: (39.6137546, -74.3626727),
        52: (39.6139079, -74.3626152),
        53: (39.6139539, -74.3625615),
        54: (39.6139424, -74.362393),
        48: (39.613904, -74.3621746),
        47: (39.6138389, -74.3619025),
        46: (39.6137947, -74.3617297),
        45: (39.6137623, -74.3615538),
        44: (39.6137163, -74.3613354),
        43: (39.6136473, -74.3610787),
        10: (39.6134711, -74.3609714),
        8: (39.6133025, -74.3610366),
        12: (39.6131799, -74.3610826),
        9: (39.6130458, -74.3611247),
        11: (39.6129078, -74.3611592),
        13: (39.6127776, -74.3612473),
        14: (39.6126818, -74.3612875),
        15: (39.6126473, -74.3613565),
        16: (39.612632, -74.3614983),
        17: (39.6126933, -74.3616784),
        18: (39.6127316, -74.3618814),
        19: (39.6127546, -74.3620845),
        20: (39.6128235, -74.3623451),
        21: (39.6128389, -74.3625328),
        25: (39.6131607, -74.3626612),
        26: (39.6131416, -74.3625156),
        27: (39.6130956, -74.3622359),
        28: (39.6130036, -74.3618029),
        29: (39.6129155, -74.3613393),
        34: (39.6134519, -74.3624428),
        33: (39.6133906, -74.3621286),
        32: (39.6133638, -74.3619102),
        31: (39.6132795, -74.3616113),
        30: (39.6132067, -74.3612588),
        42: (39.6137086, -74.3625539),
        41: (39.6136818, -74.3624121),
        40: (39.6136358, -74.3621937),
        39: (39.6135745, -74.3619255),
        35: (39.6135285, -74.3617148),
        38: (39.6135056, -74.3615692),
        37: (39.6134481, -74.3613048),
        36: (39.6134136, -74.3611668),
    }

    cv2.namedWindow('ArUco ROI', cv2.WINDOW_NORMAL)
    cv2.resizeWindow('ArUco ROI', 1000, 1080)

    while True:
        ret, frame = cap.read()

        if not ret:
            print("Error: Unable to capture a frame.")
            break

        # Apply zoom and translation to the frame
        zoomed_frame = cv2.resize(frame, None, fx=zoom_factor, fy=zoom_factor, interpolation=cv2.INTER_LINEAR)
        translated_frame = np.zeros_like(frame)

        h, w, _ = frame.shape
        translation_matrix = np.float32([[1, 0, translation_x], [0, 1, translation_y]])

        translated_frame[:h, :w] = cv2.warpAffine(zoomed_frame, translation_matrix, (w, h))

        # Call the function to detect ArUco markers
        ArUco_details_dict, ArUco_corners = detect_ArUco_details(translated_frame)

        # Call the function to mark the ArUco markers on the frame and print the nearest ID
        marked_frame = mark_ArUco_image(translated_frame, ArUco_details_dict, ArUco_corners, target_id, data_dict)

        target_ids = [4, 5, 6, 7]
        valid_ids = [id for id in target_ids if id in ArUco_details_dict]

        if valid_ids:
            # Extract the region of interest (ROI) containing the markers
            roi_corners = np.concatenate([ArUco_corners[id] for id in valid_ids], axis=0)
            x, y, w, h = cv2.boundingRect(roi_corners)
            roi = frame[y:y+h, x:x+w]

            # Display the ROI
            cv2.imshow('ArUco ROI', roi)
        else:
            cv2.imshow('Video Capture', frame)

        #cv2.imshow("Marked Frame", marked_frame)

        key = cv2.waitKey(1) & 0xFF

        if key == ord('q'):
            break
        elif key == ord('i'):
            zoom_factor *= 1.1  # Zoom in by 10%
        elif key == ord('o'):
            zoom_factor /= 1.1  # Zoom out by 10%
        elif key == ord('w'):
            translation_y -= 10  # Move up
        elif key == ord('s'):
            translation_y += 10  # Move down
        elif key == ord('a'):
            translation_x -= 10  # Move left
        elif key == ord('d'):
            translation_x += 10  # Move right

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()